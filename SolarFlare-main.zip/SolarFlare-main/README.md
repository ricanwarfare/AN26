# SolarFlare

Combined BlueHammer + RedSun 0day exploits.

BlueHammer can freeze Windows Defender and find VSS copies. RedSun can trigger a file rewrite bug using cloud tags. Alone they're cool. Together? Freeze Defender, trigger the rewrite, overwrite TieringEngineService.exe in System32. SYSTEM shell.

I think antimalware products are supposed to protect you, not help you escalate privileges. But that's just me.

BlueHammer + RedSun exploits included in this repository

Credit: [Nightmare-Eclipse](https://github.com/Nightmare-Eclipse)

