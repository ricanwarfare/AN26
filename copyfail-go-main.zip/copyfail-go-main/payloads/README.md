These are the assembly and binary payloads embedded in copyfail-go

## Scripted

Just run `build-n-print.sh`

## Manual

To build the asm run 

```shell
nasm -f bin {{ payload }}.asm -o {{ payload }}
```

To format the binary into the hex for copyfail-go, run 

```shell
cat {{ payload }} | python3 -c 'import sys, zlib; print(zlib.compress(sys.stdin.buffer.read()).hex())'
```