#!/bin/bash

# Check for nasm
if ! command -v nasm &> /dev/null; then
    echo "[!] nasm could not be found. Please install it."
    exit 1
fi

# Check for python3
if ! command -v python3 &> /dev/null; then
    echo "[!] python3 could not be found. Please install it."
    exit 1
fi

for payload in *.asm; do
    echo "[+] Building $payload"
    nasm -f bin $payload -o ${payload%.asm}
    echo "[+] Printing $payload as hex"
    cat ${payload%.asm} | python3 -c 'import sys, zlib; print(zlib.compress(sys.stdin.buffer.read()).hex())'
done

# Check for aarch64-linux-gnu-as
if ! command -v aarch64-linux-gnu-as &> /dev/null; then
    echo "[!] aarch64-linux-gnu-as could not be found. Please install binutils-aarch64-linux-gnu"
    exit 1
fi

for payload in *aarch64.S; do
    # Assemble the source into an object file
    echo "[+] Building $payload"
    aarch64-linux-gnu-as $payload -o ${payload%.S}.o
    # Extract ONLY the raw bytes into a flat binary file
    echo "[+] Extracting $payload as binary"
    aarch64-linux-gnu-objcopy -O binary ${payload%.S}.o ${payload%.S}
    echo "[+] Printing $payload as hex"
    cat ${payload%.S} | python3 -c 'import sys, zlib; print(zlib.compress(sys.stdin.buffer.read()).hex())'
done

if ! command -v arm-linux-gnueabihf-as &> /dev/null; then
    echo "[!] arm-linux-gnueabihf-as could not be found. Please install binutils-arm-linux-gnueabihf"
    exit 1
fi

for payload in *armv7l.S; do
    # Assemble the source into an object file
    echo "[+] Building $payload"
    arm-linux-gnueabihf-as $payload -o ${payload%.S}.o
    # Extract ONLY the raw bytes into a flat binary file
    echo "[+] Extracting $payload as binary"
    arm-linux-gnueabihf-objcopy -O binary ${payload%.S}.o ${payload%.S}
    echo "[+] Printing $payload as hex"
    cat ${payload%.S} | python3 -c 'import sys, zlib; print(zlib.compress(sys.stdin.buffer.read()).hex())'
done
